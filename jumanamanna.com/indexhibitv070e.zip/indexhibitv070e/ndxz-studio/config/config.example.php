<?php  if (!defined('SITE')) exit('No direct script access allowed');

$indx['db'] 		= 'databasename';
$indx['user'] 		= 'username';
$indx['pass'] 		= 'password';
$indx['host'] 		= 'localhost';
$indx['sql']		= 'mysql';

?>