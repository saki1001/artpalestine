Bonjour:

If you'd like to edit up your template do these things (if you haven't already):

- switch to Advanced mode in Settings
- select the 'Sample' template/theme

You can easily create new template sets by simply duplicating the Sample folder and renaming (keep it lowercase) - then you can select it from the template/theme option in settings.

Merci,

Vaska