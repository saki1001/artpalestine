<div id="footer">
	<ul class="nav fix">
		<li><a href="<?php echo get_settings('home'); ?>/" title="Return to the the frontpage">Home<br /><span>Frontpage</span></a></li>
		<li><a href="#" title="Link title">Link<br /><span>Short Desc</span></a></li>
		<li><a href="#" title="Link title">Link<br /><span>Short Desc</span></a></li>
		<li><a href="#" title="Link title">Link<br /><span>Short Desc</span></a></li>
		<li><a href="" title="Subscribe to the main feed via RSS">RSS<br /><span>Syndicate</span></a></li>
		<li class="top"><a href="#top" title="Return to the top">Top<br /><span>Return to top</span></a></li>
	</ul>
	<p><a href="http://5thirtyone.com/grid-focus" title="Grid Focus by: Derek Punsalan">Grid Focus</a> by Derek Punsalan <a href="http://5thirtyone.com">5thirtyone.com</a>.</p>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>