<div id="tertCol">
	<div id="elseWhere">
		<h3>Before you go</h3>
		<p>Going so soon? May these links be a guide to web enlightenment. Schwing!</p>
		<ul id="imgLinks">
			<li><a href="http://5thirtyone.com/grid-focus" title="Download Grid Focus by: Derek Punsalan"><img src="<?php bloginfo('template_directory'); ?>/images/guide/grid_focus_531.gif" alt="Grid Focus - 531" /></a></li>
			<li><a href="http://is.derekpunsalan.com/" title="Visit Derek Punsalan...is"><img src="<?php bloginfo('template_directory'); ?>/images/guide/is.gif" alt="Derek Punsalan...is" /></a></li>
		</ul>
	</div><!-- close #imgLinks -->
</div><!-- close #tertCol -->